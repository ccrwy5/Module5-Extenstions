import UIKit

extension Int {
    
    func add(_ inputNumber : String) -> Int? {
        
        if let numberToBeAdded = Int(inputNumber){
            let addedValue = self + numberToBeAdded
            return addedValue
        }else{
            return nil
        }
    }
}

let value1: Int? = 3.add("4") // value will equal 7
let value2: Int? = 2.add("Hello World") // value will be nil
