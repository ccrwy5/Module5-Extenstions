import UIKit

extension Array {
    
    func countUniqueElements(_ inputArray: Array) -> Int?{
        let count = NSSet(array: inputArray).count
        return count
    }
}

let values = [-1, -4, 0, 4, 34, 5, 0, -1, -1, -4, 0, 5]
values.countUniqueElements(values)
