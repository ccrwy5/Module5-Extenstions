import UIKit

extension String {
    
    func add(_ inputNumber: Int) -> Int? {
        if let convertedNumber = Int(self){
            let math = convertedNumber + inputNumber
            return math
        } else {
            return nil
        }
        
        
    }
}

let value: Int? = "3".add(4) // value will equal 7
let value2: Int? = "Hello World".add(2) // value will be nil
